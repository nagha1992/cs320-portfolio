import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        futureDate = calendar.getTime();
    }

    @Test
    public void testAddAppointment() {
        Appointment appt = new Appointment("1", futureDate, "Project review.");
        assertTrue(service.addAppointment(appt));
        assertEquals(appt, service.getAppointment("1"));
    }

    @Test
    public void testAddDuplicateIdFails() {
        Appointment appt1 = new Appointment("1", futureDate, "Review 1");
        Appointment appt2 = new Appointment("1", futureDate, "Review 2");
        assertTrue(service.addAppointment(appt1));
        assertFalse(service.addAppointment(appt2));
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appt = new Appointment("1", futureDate, "Review");
        service.addAppointment(appt);
        assertTrue(service.deleteAppointment("1"));
        assertNull(service.getAppointment("1"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        assertFalse(service.deleteAppointment("999"));
    }
}