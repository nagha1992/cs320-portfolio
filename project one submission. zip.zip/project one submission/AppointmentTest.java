import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentCreationSuccess() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // Set to tomorrow
        Date futureDate = calendar.getTime();

        Appointment appt = new Appointment("12345", futureDate, "Consultation meeting.");
        assertEquals("12345", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Consultation meeting.", appt.getDescription());
    }

    @Test
    public void testAppointmentIdTooLongOrNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000L); // Tomorrow

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
    }

    @Test
    public void testAppointmentDateInPastOrNull() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1); // Set to yesterday
        Date pastDate = calendar.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Description");
        });
    }

    @Test
    public void testDescriptionTooLongOrNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000L);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "This description string is intentionally made to exceed the fifty character max limit.");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null);
        });
    }
}