import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;



public class TaskServiceTest {

    private TaskService service;



    @BeforeEach

    public void setUp() {

        service = new TaskService();

    }



    @Test

    public void testAddTask() {

        Task task = new Task("1", "Study", "Read chapter 4 of Java testing.");

        assertTrue(service.addTask(task));

        assertEquals(task, service.getTask("1"));

    }



    @Test

    public void testAddDuplicateTaskIdFails() {

        Task task1 = new Task("1", "Study", "Read chapter 4.");

        Task task2 = new Task("1", "Work out", "Go for a 30 min run.");

        assertTrue(service.addTask(task1));

        assertFalse(service.addTask(task2));

    }



    @Test

    public void testDeleteTask() {

        Task task = new Task("1", "Study", "Read chapter 4.");

        service.addTask(task);

        assertTrue(service.deleteTask("1"));

        assertNull(service.getTask("1"));

    }



    @Test

    public void testUpdateTaskFields() {

        Task task = new Task("1", "Study", "Read chapter 4.");

        service.addTask(task);



        assertTrue(service.updateName("1", "Updated Name"));

        assertEquals("Updated Name", service.getTask("1").getName());



        assertTrue(service.updateDescription("1", "Updated description text under 50 chars."));

        assertEquals("Updated description text under 50 chars.", service.getTask("1").getDescription());

    }

}