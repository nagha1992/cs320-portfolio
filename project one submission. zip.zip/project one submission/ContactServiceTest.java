import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;



public class ContactServiceTest {

    private ContactService service;



    @BeforeEach

    public void setUp() {

        service = new ContactService();

    }



    @Test

    public void testAddContact() {

        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        assertTrue(service.addContact(contact));

        assertEquals(contact, service.getContact("1"));

    }



    @Test

    public void testAddDuplicateContactIdFails() {

        Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        Contact contact2 = new Contact("1", "Jane", "Smith", "0987654321", "456 Elm St");

        assertTrue(service.addContact(contact1));

        assertFalse(service.addContact(contact2));

    }



    @Test

    public void testDeleteContact() {

        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        assertTrue(service.deleteContact("1"));

        assertNull(service.getContact("1"));

    }



    @Test

    public void testUpdateContactFields() {

        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);



        assertTrue(service.updateFirstName("1", "Jane"));

        assertEquals("Jane", service.getContact("1").getFirstName());



        assertTrue(service.updateLastName("1", "Smith"));

        assertEquals("Smith", service.getContact("1").getLastName());



        assertTrue(service.updatePhone("1", "0987654321"));

        assertEquals("0987654321", service.getContact("1").getPhone());



        assertTrue(service.updateAddress("1", "456 Elm St"));

        assertEquals("456 Elm St", service.getContact("1").getAddress());

    }

}