import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



public class TaskTest {



    @Test

    public void testTaskCreationSuccess() {

        Task task = new Task("1234567890", "Complete Assignment", "Finish Module Four Milestone by Sunday.");

        assertEquals("1234567890", task.getTaskId());

        assertEquals("Complete Assignment", task.getName());

        assertEquals("Finish Module Four Milestone by Sunday.", task.getDescription());

    }



    @Test

    public void testTaskIdTooLongOrNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Task("12345678901", "Task Name", "Task Description");

        });

        assertThrows(IllegalArgumentException.class, () -> {

            new Task(null, "Task Name", "Task Description");

        });

    }



    @Test

    public void testNameTooLongOrNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Task("123", "This Name Is Way Too Long To Be Valid", "Task Description");

        });

        assertThrows(IllegalArgumentException.class, () -> {

            new Task("123", null, "Task Description");

        });

    }



    @Test

    public void testDescriptionTooLongOrNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Task("123", "Task Name", "This description string is intentionally made to exceed the fifty character max limit.");

        });

        assertThrows(IllegalArgumentException.class, () -> {

            new Task("123", "Task Name", null);

        });

    }

}